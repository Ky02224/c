package com.example.coffeeshop.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.PreferenceManager
import com.example.coffeeshop.R

@SuppressLint("CustomSplashScreen")
class SplashScreenActivity : AppCompatActivity() {

    private val SPLASH_TIME_OUT: Long = 1500

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.splash_screen)

        if (shouldSkipSplashScreen()) {
            startMainActivity()
        } else {
            Handler(Looper.getMainLooper()).postDelayed({
                startMainActivity()
            }, SPLASH_TIME_OUT)
        }
    }

    private fun shouldSkipSplashScreen(): Boolean {
        val preferences: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)
        return preferences.getBoolean("skip_splash", false)
    }

    private fun startMainActivity() {
        val intent = Intent(this@SplashScreenActivity, MainActivity::class.java)
        startActivity(intent)
        finish() // Close splash screen so the user cannot go back to it
    }
}
