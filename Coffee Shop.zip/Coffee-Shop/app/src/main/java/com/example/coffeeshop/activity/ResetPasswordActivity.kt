package com.example.coffeeshop.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.coffeeshop.R
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.button.MaterialButton
import org.json.JSONArray
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.*

class ResetPasswordActivity : AppCompatActivity() {

    private lateinit var emailOrPhoneEditText: TextInputEditText
    private lateinit var sendResetButton: MaterialButton
    private lateinit var backButton: ImageView

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reset_password)

        emailOrPhoneEditText = findViewById(R.id.emailOrPhoneEditText)
        sendResetButton = findViewById(R.id.sendResetButton)
        backButton = findViewById(R.id.ivBack)

        sendResetButton.setOnClickListener {
            val emailOrPhone = emailOrPhoneEditText.text?.toString()?.trim()

            if (emailOrPhone.isNullOrEmpty()) {
                Toast.makeText(this, "Please enter your email or phone", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val resetCode = generateResetToken(emailOrPhone)
            if (resetCode != null) {
                showResetTokenDialog(resetCode, emailOrPhone)
            } else {
                Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show()
            }
        }
        backButton.setOnClickListener {
            finish()
        }
    }

    private fun getUsersJson(): JSONArray? {
        return try {
            val inputStream = assets.open("users.json")
            val reader = BufferedReader(InputStreamReader(inputStream))
            val content = reader.use { it.readText() }
            JSONArray(content)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun generateResetToken(emailOrPhone: String): String? {
        val usersArray = getUsersJson() ?: return null

        for (i in 0 until usersArray.length()) {
            val userObject = usersArray.getJSONObject(i)
            val email = userObject.optString("email", "")
            val phone = userObject.optString("phone", "")

            if (email == emailOrPhone || phone == emailOrPhone) {
                val resetToken = UUID.randomUUID().toString().substring(0, 6)

                userObject.put("resetToken", resetToken)
                saveUsersJson(usersArray)  // **保存 JSON 文件**
                return resetToken
            }
        }
        return null
    }

    private fun showResetTokenDialog(resetToken: String, emailOrPhone: String) {
        val alertDialog = android.app.AlertDialog.Builder(this)
            .setTitle("Password Reset Token")
            .setMessage("Your reset token is: $resetToken\nPlease remember this code to reset your password.")
            .setPositiveButton("Proceed") { _, _ ->
                val intent = Intent(this, NewPasswordActivity::class.java)
                intent.putExtra("resetToken", resetToken)
                intent.putExtra("emailOrPhone", emailOrPhone)
                startActivity(intent)
            }
            .setNegativeButton("Cancel", null)
            .create()

        alertDialog.show()
    }
    private fun saveUsersJson(usersArray: JSONArray) {
        try {
            val fileOutputStream = openFileOutput("users.json", MODE_PRIVATE)
            fileOutputStream.write(usersArray.toString().toByteArray())
            fileOutputStream.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


}
