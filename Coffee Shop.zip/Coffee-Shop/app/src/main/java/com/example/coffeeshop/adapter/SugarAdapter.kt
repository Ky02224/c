package com.example.coffeeshop.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.coffeeshop.R
import com.example.coffeeshop.databinding.ViewholderSugarBinding

class SugarAdapter(private val context: Context, private val items: List<String>) :
    RecyclerView.Adapter<SugarAdapter.ViewHolder>() {

    private var selectedPosition = -1
    private var lastSelectedPosition = -1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ViewholderSugarBinding.inflate(
            LayoutInflater.from(context), parent, false
        )
        return ViewHolder(binding)
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onBindViewHolder(holder: ViewHolder, @SuppressLint("RecyclerView") position: Int) {
        holder.binding.sugarLevelText.text = items[position]
        val sugarIcons = listOf(
            R.drawable.sugar_0,  // 0%
            R.drawable.sugar_25, // 25%
            R.drawable.sugar_50, // 50%
            R.drawable.sugar_75, // 75%
            R.drawable.sugar_100 // 100%
        )
        holder.binding.sugarIcon.setImageResource(sugarIcons[position])

        holder.binding.root.setOnClickListener {
            lastSelectedPosition = selectedPosition
            selectedPosition = position
            notifyItemChanged(lastSelectedPosition)
            notifyItemChanged(selectedPosition)
        }

        if (selectedPosition == position) {
            holder.binding.sugarIcon.setBackgroundResource(R.drawable.orange_bg)
        } else {
            holder.binding.sugarIcon.setBackgroundResource(R.drawable.size_bg)
        }
    }

    override fun getItemCount(): Int = items.size

    class ViewHolder(val binding: ViewholderSugarBinding) :
        RecyclerView.ViewHolder(binding.root)
}
