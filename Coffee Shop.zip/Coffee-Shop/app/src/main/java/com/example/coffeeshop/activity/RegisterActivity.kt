package com.example.coffeeshop.activity

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.coffeeshop.R
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.nio.charset.Charset

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val emailEditText = findViewById<EditText>(R.id.emailEditText)
        val phoneEditText = findViewById<EditText>(R.id.phoneEditText)
        val passwordEditText = findViewById<EditText>(R.id.passwordEditText)
        val paymentDetailsEditText = findViewById<EditText>(R.id.paymentDetailsEditText)
        val selectAddressButton = findViewById<Button>(R.id.selectAddressButton)
        val registerButton = findViewById<Button>(R.id.registerButton)
        val backButton = findViewById<ImageView>(R.id.ivBack)


        selectAddressButton.setOnClickListener {
            val intent = Intent(this, MapsActivity::class.java)
            startActivity(intent)
        }


        registerButton.setOnClickListener {
            val email = emailEditText.text.toString()
            val phone = phoneEditText.text.toString()
            val password = passwordEditText.text.toString()
            val paymentDetails = paymentDetailsEditText.text.toString()

            if (email.isNotEmpty() && phone.isNotEmpty() && password.isNotEmpty() && paymentDetails.isNotEmpty()) {
                saveUserData(email, phone, password, paymentDetails)
                Toast.makeText(this, "Registration successful!", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "Please fill in all fields.", Toast.LENGTH_SHORT).show()
            }
        }

        backButton.setOnClickListener {
            finish()
        }
    }

    private fun saveUserData(email: String, phone: String, password: String, paymentDetails: String) {
        val fileName = "users.json"
        val file = File(filesDir, fileName)
        val userObject = JSONObject().apply {
            put("email", email)
            put("phone", phone)
            put("password", password)
            put("paymentDetails", paymentDetails)
        }

        val usersArray = if (file.exists()) {
            val content = file.readText(Charset.defaultCharset())
            if (content.isNotEmpty()) JSONArray(content) else JSONArray()
        } else {
            JSONArray()
        }

        usersArray.put(userObject)
        FileOutputStream(file).use { it.write(usersArray.toString().toByteArray()) }
    }
}
