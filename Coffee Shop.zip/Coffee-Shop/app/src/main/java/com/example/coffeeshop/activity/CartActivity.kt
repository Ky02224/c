package com.example.coffeeshop.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.coffeeshop.adapter.CartAdapter
import com.example.coffeeshop.databinding.ActivityCartBinding
import com.example.coffeeshop.helper.ChangeNumberItemsListener
import com.example.coffeeshop.helper.ManagmentCart

class CartActivity : BaseActivity() {

    lateinit var management: ManagmentCart
    private var tax: Double = 0.0
    private val binding: ActivityCartBinding by lazy {
        ActivityCartBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        management = ManagmentCart(this)

        calculateCart()
        setVariable()
        initCartList()
    }

    private fun initCartList() {
        with(binding) {
            rvCartView.layoutManager =
                LinearLayoutManager(this@CartActivity, LinearLayoutManager.VERTICAL, false)
            rvCartView.adapter = CartAdapter(
                management.getListCart(),
                this@CartActivity,
                object : ChangeNumberItemsListener {
                    override fun onChanged() {
                        calculateCart()
                    }
                }
            )
        }
    }

    private fun setVariable() {
        binding.ivBack.setOnClickListener { finish() }

        binding.proceedCheckoutBtn.setOnClickListener {
            val intent = Intent(this, PaymentActivity::class.java)
            intent.putExtra("totalAmount", (management.getTotalFee() + tax + 5.00))
            startActivity(intent)
        }
    }


    @SuppressLint("SetTextI18n", "DefaultLocale")
    private fun calculateCart() {
        val percentTax = 0.06
        val delivery = 5.00
        tax = Math.round((management.getTotalFee() * percentTax) * 100) / 100.0
        val total = (management.getTotalFee() + tax + delivery)
        val itemTotal = management.getTotalFee()

        with(binding) {
            subTotalPriceTxt.text = String.format("$%.2f", itemTotal)
            totalTaxPriceTxt.text = String.format("$%.2f", tax)
            deliveryPriceTxt.text = String.format("$%.2f", delivery)
            totalPriceTxt.text = String.format("$%.2f", total)
        }
    }
}
