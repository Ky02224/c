package com.example.coffeeshop.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.coffeeshop.databinding.ViewholderCategoryBinding
import com.example.coffeeshop.model.CategoryModel

class CategoryAdapter(
    private var categories: List<CategoryModel>,
    private val onCategoryClick: (Int?) -> Unit
) : RecyclerView.Adapter<CategoryAdapter.ViewHolder>() {

    private var selectedCategoryId: Int? = null
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ViewholderCategoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val category = categories[position]

        holder.binding.categoryTxt.text = category.category
        holder.binding.root.setOnClickListener {
            if (selectedCategoryId == category.categoryId) {
                selectedCategoryId = null
                onCategoryClick(null)
            } else {
                selectedCategoryId = category.categoryId
                onCategoryClick(category.categoryId)
            }

            holder.itemView.post {
                notifyDataSetChanged()
            }
        }
    }


    override fun getItemCount(): Int = categories.size

    class ViewHolder(val binding: ViewholderCategoryBinding) : RecyclerView.ViewHolder(binding.root)
}
