package com.example.coffeeshop.activity

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import com.example.coffeeshop.R
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class OrderTrackingBottomSheet : BottomSheetDialogFragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.bottom_sheet_order_tracking, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val trackOrderButton: Button = view.findViewById(R.id.btnTrackOrder)
        val proceedPaymentButton: Button = view.findViewById(R.id.btnProceedPayment)

        trackOrderButton.setOnClickListener {
            val intent = Intent(requireContext(), OrderTrackingActivity::class.java)
            startActivity(intent)
            dismiss()
        }

        proceedPaymentButton.setOnClickListener {
            val intent = Intent(requireContext(), PaymentActivity::class.java)
            startActivity(intent)
            dismiss()
        }
    }
}
