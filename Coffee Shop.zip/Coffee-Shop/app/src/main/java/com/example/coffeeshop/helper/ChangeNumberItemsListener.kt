package com.example.coffeeshop.helper

interface ChangeNumberItemsListener {
    fun onChanged()
}