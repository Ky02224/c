package com.example.coffeeshop.model

data class CategoryModel(
    val categoryId: Int,
    val category: String

)
