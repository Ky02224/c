package com.example.coffeeshop.activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.coffeeshop.R
import org.json.JSONArray
import java.io.File
import java.nio.charset.Charset

class LoginActivity : AppCompatActivity() {

    private lateinit var loginLayout: LinearLayout
    private lateinit var profileLayout: LinearLayout
    private lateinit var emailInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var loginButton: Button
    private lateinit var registerButton: Button
    private lateinit var userEmail: TextView
    private lateinit var logoutButton: Button
    private lateinit var backButton: ImageView
    private lateinit var userAvatar: ImageView
    private lateinit var forgotPasswordButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        loginLayout = findViewById(R.id.loginLayout)
        profileLayout = findViewById(R.id.profileLayout)
        emailInput = findViewById(R.id.emailInput)
        passwordInput = findViewById(R.id.passwordInput)
        loginButton = findViewById(R.id.loginButton)
        registerButton = findViewById(R.id.registerButton)
        userEmail = findViewById(R.id.userEmail)
        logoutButton = findViewById(R.id.logoutButton)
        userAvatar = findViewById(R.id.userAvatar)
        forgotPasswordButton = findViewById(R.id.forgotPasswordButton)
        backButton = findViewById(R.id.ivBack)

        val sharedPreferences = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        val savedEmail = sharedPreferences.getString("email", null)

        if (savedEmail != null) {
            showUserProfile(savedEmail)
        } else {
            showLoginScreen()
        }

        forgotPasswordButton.setOnClickListener {
            val intent = Intent(this, ResetPasswordActivity::class.java)
            startActivity(intent)
        }
        loginButton.setOnClickListener {
            val email = emailInput.text.toString()
            val password = passwordInput.text.toString()

            if (email.isNotEmpty() && password.isNotEmpty())
            {
                if (validateUser(email, password)) {
                    sharedPreferences.edit().putString("email", email).apply()
                    showUserProfile(email)
                    Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                } else {
                    Toast.makeText(this, "Login failed: Invalid credentials", Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show()
            }
        }

        registerButton.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }


        logoutButton.setOnClickListener {
            sharedPreferences.edit().remove("email").apply()
            showLoginScreen()
        }
        backButton.setOnClickListener {
            finish()
        }
    }

    private fun showUserProfile(email: String) {
        loginLayout.visibility = View.GONE
        profileLayout.visibility = View.VISIBLE
        userEmail.text = email
    }

    private fun showLoginScreen() {
        loginLayout.visibility = View.VISIBLE
        profileLayout.visibility = View.GONE
    }
    private fun validateUser(email: String, password: String): Boolean {
        val fileName = "users.json"
        val file = File(filesDir, fileName)
        if (!file.exists()) return false

        val content = file.readText(Charset.defaultCharset())
        val usersArray = JSONArray(content)
        for (i in 0 until usersArray.length()) {
            val userObject = usersArray.getJSONObject(i)
            if (userObject.getString("email") == email && userObject.getString("password") == password) {
                return true
            }
        }
        return false
    }
}
