package com.example.coffeeshop.activity

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.example.coffeeshop.R

class SettingActivity : AppCompatActivity() {

    private lateinit var emailText: TextView
    private lateinit var editUsername: EditText
    private lateinit var saveUsernameButton: Button
    private lateinit var themeToggleButton: Button
    private lateinit var backButton: ImageView
    private lateinit var sharedPreferences: SharedPreferences

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setting)

        emailText = findViewById(R.id.emailText)
        editUsername = findViewById(R.id.editUsername)
        saveUsernameButton = findViewById(R.id.saveUsernameButton)
        themeToggleButton = findViewById(R.id.themeToggleButton)
        backButton = findViewById(R.id.ivBack)

        sharedPreferences = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)

        val userEmail = sharedPreferences.getString("email", "No email found")
        emailText.text = "Email: $userEmail"

        val savedUsername = sharedPreferences.getString("username", "")
        editUsername.setText(savedUsername)

        saveUsernameButton.setOnClickListener {
            val newUsername = editUsername.text.toString()
            if (newUsername.isNotEmpty()) {
                sharedPreferences.edit().putString("username", newUsername).apply()
            }
        }

        updateThemeButtonText()
        themeToggleButton.setOnClickListener {
            toggleTheme()
        }

        backButton.setOnClickListener {
            finish()
        }
    }

    private fun toggleTheme() {
        val isDarkMode = sharedPreferences.getBoolean("darkMode", false)
        val newMode = if (isDarkMode) {
            AppCompatDelegate.MODE_NIGHT_NO
        } else {
            AppCompatDelegate.MODE_NIGHT_YES
        }

        sharedPreferences.edit().putBoolean("darkMode", !isDarkMode).apply()
        AppCompatDelegate.setDefaultNightMode(newMode)
        recreate()
    }

    private fun updateThemeButtonText() {
        val isDarkMode = sharedPreferences.getBoolean("darkMode", false)
        themeToggleButton.text = if (isDarkMode) "Switch to Light Mode" else "Switch to Dark Mode"
    }
}
