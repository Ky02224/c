package com.example.coffeeshop.helper

import android.content.Context
import android.widget.Toast
import com.example.coffeeshop.model.ItemsModel

class ManagmentCart(private val context: Context) {

    private val tinyDB = TinyDB(context)

    fun insertItems(item: ItemsModel) {
        val listItem = getListCart()
        val index = listItem.indexOfFirst { it.title == item.title }

        if (index != -1) {
            listItem[index].numberInCart += item.numberInCart
        } else {
            listItem.add(item)
        }
        tinyDB.putListObject("CartList", listItem)
        Toast.makeText(context, "Added to your Cart", Toast.LENGTH_SHORT).show()
    }

    fun getListCart(): ArrayList<ItemsModel> {
        return tinyDB.getListObject("CartList") ?: arrayListOf()
    }

    fun minusItem(listItems: ArrayList<ItemsModel>, position: Int, listener: () -> Unit) {
        if (listItems[position].numberInCart > 1) {
            listItems[position].numberInCart--
        } else {
            listItems.removeAt(position)
        }
        tinyDB.putListObject("CartList", listItems)
        listener()
    }

    fun plusItem(listItems: ArrayList<ItemsModel>, position: Int, listener: () -> Unit) {
        listItems[position].numberInCart++
        tinyDB.putListObject("CartList", listItems)
        listener()
    }

    fun getTotalFee(): Double {
        return getListCart().sumOf { it.price * it.numberInCart }
    }
}
