package com.example.coffeeshop.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.coffeeshop.R
import com.example.coffeeshop.adapter.CartAdapter
import com.example.coffeeshop.helper.ChangeNumberItemsListener
import com.example.coffeeshop.helper.ManagmentCart

class PaymentActivity : AppCompatActivity() {
    private lateinit var managementCart: ManagmentCart
    private lateinit var totalPriceTextView: TextView
    private lateinit var paymentMethodSpinner: Spinner
    private lateinit var confirmPaymentButton: Button
    private lateinit var rvOrderList: RecyclerView
    private lateinit var ivBack: ImageView

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment)

        managementCart = ManagmentCart(this)

        totalPriceTextView = findViewById(R.id.totalPriceTextView)
        paymentMethodSpinner = findViewById(R.id.paymentMethodSpinner)
        confirmPaymentButton = findViewById(R.id.confirmPaymentButton)
        rvOrderList = findViewById(R.id.rvOrderList)
        ivBack = findViewById(R.id.ivBack)

        displayOrderDetails()

        ivBack.setOnClickListener { finish() }

        setupPaymentMethods()

        confirmPaymentButton.setOnClickListener {
            val selectedPaymentMethod = paymentMethodSpinner.selectedItem.toString()
            Toast.makeText(this, "Payment successful via $selectedPaymentMethod!", Toast.LENGTH_SHORT).show()

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)

            finish()
        }
    }

    @SuppressLint("DefaultLocale")
    private fun displayOrderDetails() {

        val subtotal = managementCart.getTotalFee()

        val taxRate = 0.06
        val taxAmount = subtotal * taxRate

        val deliveryFee = 5.00

        val finalTotal = subtotal + taxAmount + deliveryFee

        totalPriceTextView.text = String.format("Subtotal: $%.2f\nTax: $%.2f\nDelivery: $%.2f\nTotal: $%.2f",
            subtotal, taxAmount, deliveryFee, finalTotal)


        rvOrderList.layoutManager = LinearLayoutManager(this)
        rvOrderList.adapter = CartAdapter(
            managementCart.getListCart(),
            this,
            object : ChangeNumberItemsListener {
                override fun onChanged() {
                    updateTotalPrice()
                }
            }
        )
    }

    @SuppressLint("DefaultLocale")
    private fun updateTotalPrice() {
        val subtotal = managementCart.getTotalFee()
        val taxRate = 0.06
        val taxAmount = subtotal * taxRate
        val deliveryFee = 5.00
        val finalTotal = subtotal + taxAmount + deliveryFee

        totalPriceTextView.text = String.format("Subtotal: $%.2f\nTax: $%.2f\nDelivery: $%.2f\nTotal: $%.2f",
            subtotal, taxAmount, deliveryFee, finalTotal)
    }


    private fun setupPaymentMethods() {
        val paymentMethods = arrayOf("Credit Card", "PayPal", "Google Pay", "Cash on Delivery")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, paymentMethods)
        paymentMethodSpinner.adapter = adapter
    }


}
