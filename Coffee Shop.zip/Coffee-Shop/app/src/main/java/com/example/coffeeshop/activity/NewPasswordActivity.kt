package com.example.coffeeshop.activity

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.coffeeshop.R
import com.example.coffeeshop.utils.UserJsonHandler
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class NewPasswordActivity : AppCompatActivity() {

    private lateinit var newPasswordInput: TextInputLayout
    private lateinit var newPasswordEditText: TextInputEditText
    private lateinit var confirmPasswordInput: TextInputLayout
    private lateinit var confirmPasswordEditText: TextInputEditText
    private lateinit var resetButton: Button
    private lateinit var backButton: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_password)

        newPasswordInput = findViewById(R.id.newPasswordInput)
        newPasswordEditText = findViewById(R.id.newPasswordEditText)
        confirmPasswordInput = findViewById(R.id.confirmPasswordInput)
        confirmPasswordEditText = findViewById(R.id.confirmPasswordEditText)
        resetButton = findViewById(R.id.resetButton)
        backButton = findViewById(R.id.ivBack)


        val emailOrPhone = intent.getStringExtra("emailOrPhone")
        val resetToken = intent.getStringExtra("resetToken")

        resetButton.setOnClickListener {
            val newPassword = newPasswordEditText.text.toString().trim()
            val confirmPassword = confirmPasswordEditText.text.toString().trim()

            if (newPassword.isEmpty() || confirmPassword.isEmpty()) {
                Toast.makeText(this, "Please enter your new password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (newPassword != confirmPassword) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val userObject = UserJsonHandler.findUserByEmailOrPhone(this, emailOrPhone ?: "")
            if (userObject != null && userObject.optString("resetToken") == resetToken) {
                if (UserJsonHandler.updateUserPassword(this, emailOrPhone!!, newPassword)) {
                    Toast.makeText(this, "Password reset successful", Toast.LENGTH_LONG).show()
                    finish()
                } else {
                    Toast.makeText(this, "Failed to reset password", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Invalid reset token", Toast.LENGTH_SHORT).show()
            }
        }
        backButton.setOnClickListener {
            finish()
        }
    }
}
