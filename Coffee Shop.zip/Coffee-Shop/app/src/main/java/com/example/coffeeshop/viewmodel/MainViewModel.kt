package com.example.coffeeshop.viewmodel

import android.content.Context
import com.example.coffeeshop.model.CategoryModel
import com.example.coffeeshop.model.ItemsModel
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.IOException
import java.io.InputStreamReader

class MainViewModel {

    fun loadCategoryFromJson(context: Context): List<CategoryModel> {
        val inputStream = context.assets.open("category.json")
        val reader = InputStreamReader(inputStream)
        val categoryListType = object : TypeToken<List<CategoryModel>>() {}.type
        return Gson().fromJson(reader, categoryListType)
    }
    fun loadPopularFromJson(context: Context): List<ItemsModel> {
        return try {
            val json = context.assets.open("popular_items.json").bufferedReader().use { it.readText() }
            val type = object : TypeToken<List<ItemsModel>>() {}.type
            Gson().fromJson(json, type)
        } catch (e: IOException) {
            e.printStackTrace()
            emptyList()
        }
    }

}
