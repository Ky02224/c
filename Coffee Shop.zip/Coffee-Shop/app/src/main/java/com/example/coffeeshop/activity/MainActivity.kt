package com.example.coffeeshop.activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.PopupMenu
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.coffeeshop.R
import com.example.coffeeshop.adapter.CategoryAdapter
import com.example.coffeeshop.adapter.PopularAdapter
import com.example.coffeeshop.adapter.VeganFilterAdapter
import com.example.coffeeshop.databinding.ActivityMainBinding
import com.example.coffeeshop.model.CategoryModel
import com.example.coffeeshop.model.ItemsModel
import com.example.coffeeshop.viewmodel.MainViewModel


class MainActivity : AppCompatActivity() {
    private val viewModel = MainViewModel()
    private lateinit var popularAdapter: PopularAdapter
    private lateinit var allPopularItems: List<ItemsModel>
    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: CategoryAdapter
    private var categoryList: List<CategoryModel> = listOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        val sharedPreferences = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        val isDarkMode = sharedPreferences.getBoolean("darkMode", false)

        AppCompatDelegate.setDefaultNightMode(
            if (isDarkMode) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val veganFilterAdapter = VeganFilterAdapter { isVeganSelected ->
            filterByVegan(isVeganSelected)
        }

        binding.recyclerViewVeg.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.recyclerViewVeg.adapter = veganFilterAdapter


        binding.bottomNavigation.background = null

        initCategory()
        initMenu()
        setupSearchFunctionality()
        setupBottomNavigation()
        bottomCart()
        setupVegan()

    }



    private fun setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.menu -> return@setOnItemSelectedListener true
                R.id.payment -> {
                    showPaymentOptionsMenu()
                    return@setOnItemSelectedListener true
                }
                R.id.profile -> {
                    startActivity(Intent(this, LoginActivity::class.java))
                    return@setOnItemSelectedListener true
                }
                R.id.setting -> {
                    startActivity(Intent(this, SettingActivity::class.java))
                    return@setOnItemSelectedListener true
                }
            }
            false
        }
    }

    private fun setupVegan() {
    binding.chipGroupVeg.setOnCheckedChangeListener { group, checkedId ->
        when (checkedId) {
            R.id.chipVeg -> {
                binding.recyclerViewVeg.visibility = View.VISIBLE
                binding.recyclerViewNonVeg.visibility = View.GONE
            }
            R.id.chipNonVeg -> {
                binding.recyclerViewVeg.visibility = View.GONE
                binding.recyclerViewNonVeg.visibility = View.VISIBLE
            }
            else -> {
                binding.recyclerViewVeg.visibility = View.GONE
                binding.recyclerViewNonVeg.visibility = View.GONE
            }
        }
    }
    }

    private fun bottomCart() {
        binding.cartBtn.setOnClickListener {
            val intent = Intent(this@MainActivity, CartActivity::class.java)
            startActivity(intent)
        }
    }

    private fun initMenu() {
        binding.progressBarPopular.visibility = View.VISIBLE
        allPopularItems = viewModel.loadPopularFromJson(this)
        popularAdapter = PopularAdapter(allPopularItems)
        binding.recyclerViewPopular.layoutManager = GridLayoutManager(this, 2)
        binding.recyclerViewPopular.adapter = popularAdapter
        binding.progressBarPopular.visibility = View.GONE
    }

    private fun initCategory() {
        binding.progressBarCategory.visibility = View.VISIBLE
        categoryList = viewModel.loadCategoryFromJson(this)
        adapter = CategoryAdapter(categoryList) { selectedCategory ->
            filterByCategory(selectedCategory)
        }


        binding.recyclerViewCategory.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.recyclerViewCategory.adapter = adapter

        binding.progressBarCategory.visibility = View.GONE
    }

    private fun setupSearchFunctionality() {
        binding.editTextText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s.toString().trim()
                filterMenuBySearch(query)
            }

            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun filterMenuBySearch(query: String) {
        val filteredList = allPopularItems.filter { it.title.contains(query, ignoreCase = true) }
        popularAdapter.updateData(filteredList)
    }

    fun filterByCategory(categoryId: Int?) {
        val filteredCoffeeList = if (categoryId == null) {
            allPopularItems
        } else {
            allPopularItems.filter { it.id == categoryId }
        }

        binding.recyclerViewPopular.post {
            popularAdapter.updateData(filteredCoffeeList)
        }
    }

    private fun filterByVegan(isVeganSelected: Boolean?) {
        val filteredList = when (isVeganSelected) {
            true -> allPopularItems.filter { it.category == "Vegan" }
            false -> allPopularItems.filter { it.category != "Vegan" }
            null -> allPopularItems
        }
        binding.recyclerViewPopular.post {
            popularAdapter.updateData(filteredList)
        }
    }




    private fun showPaymentOptionsMenu() {
        val popupMenu = PopupMenu(this, binding.bottomNavigation.findViewById(R.id.payment))
        popupMenu.menuInflater.inflate(R.menu.payment_menu, popupMenu.menu)

        popupMenu.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.option_payment -> {
                    startActivity(Intent(this, PaymentActivity::class.java))
                    true
                }
                R.id.option_order_tracking -> {
                    startActivity(Intent(this, OrderTrackingActivity::class.java))
                    true
                }
                else -> false
            }
        }

        popupMenu.show()
    }
}
