package com.example.coffeeshop.utils

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.charset.Charset

object UserJsonHandler {

    private const val FILE_NAME = "users.json"

    fun readUsersJson(context: Context): JSONArray {
        val file = File(context.filesDir, FILE_NAME)
        return if (file.exists()) {
            val content = file.readText(Charset.defaultCharset())
            JSONArray(content)
        } else {
            JSONArray()
        }
    }

    fun writeUsersJson(context: Context, usersArray: JSONArray) {
        val file = File(context.filesDir, FILE_NAME)
        file.writeText(usersArray.toString(2))
    }

    fun findUserByEmailOrPhone(context: Context, emailOrPhone: String): JSONObject? {
        val usersArray = readUsersJson(context)
        for (i in 0 until usersArray.length()) {
            val userObject = usersArray.getJSONObject(i)
            if (userObject.getString("email") == emailOrPhone || userObject.getString("phone") == emailOrPhone) {
                return userObject
            }
        }
        return null
    }
    fun updateUserPassword(context: Context, emailOrPhone: String, newPassword: String): Boolean {
        val usersArray = readUsersJson(context)
        for (i in 0 until usersArray.length()) {
            val userObject = usersArray.getJSONObject(i)
            if (userObject.getString("email") == emailOrPhone || userObject.getString("phone") == emailOrPhone) {
                userObject.put("password", newPassword)
                userObject.remove("resetToken") // 移除验证码
                writeUsersJson(context, usersArray)
                return true
            }
        }
        return false
    }
}
