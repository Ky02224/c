package com.example.coffeeshop.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.coffeeshop.databinding.ViewholderCategoryBinding

class VeganFilterAdapter(
    private val onVeganFilterClick: (Boolean?) -> Unit
) : RecyclerView.Adapter<VeganFilterAdapter.ViewHolder>() {

    private var selectedFilter: Boolean? = null

    private val filterOptions = listOf("Vegan", "Non-Vegan")

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ViewholderCategoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val filterOption = filterOptions[position]

        holder.binding.categoryTxt.text = filterOption

        val isSelected = when (filterOption) {
            "Vegan" -> selectedFilter == true
            "Non-Vegan" -> selectedFilter == false
            else -> false
        }

        holder.binding.root.isSelected = isSelected

        holder.binding.root.setOnClickListener {

            selectedFilter = when (filterOption) {
                "Vegan" -> if (selectedFilter == true) null else true
                "Non-Vegan" -> if (selectedFilter == false) null else false
                else -> null
            }

            onVeganFilterClick(selectedFilter)
            notifyDataSetChanged()
        }
    }

    override fun getItemCount(): Int = filterOptions.size

    class ViewHolder(val binding: ViewholderCategoryBinding) : RecyclerView.ViewHolder(binding.root)
}
